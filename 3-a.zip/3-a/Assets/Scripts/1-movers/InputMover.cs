﻿using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

/**
 * This component moves its object when the player clicks the arrow keys and allows dodging.
 */
public class InputMover : MonoBehaviour
{
    [Tooltip("Speed of movement, in meters per second")]
    [SerializeField] private float speed = 10f;

    [Tooltip("Speed during dodge")]
    [SerializeField] private float dodgeSpeed = 25f;

    [Tooltip("Duration of dodge, in seconds")]
    [SerializeField] private float dodgeDuration = 0.2f;

    [Tooltip("Cooldown time for dodging, in seconds")]
    [SerializeField] private float dodgeCooldown = 1f;

    private float offSet = 0.1f;

    [SerializeField]
    private InputAction move = new InputAction(
        type: InputActionType.Value, expectedControlType: nameof(Vector2));

    [SerializeField]
    private InputAction dodge = new InputAction(
        type: InputActionType.Button, expectedControlType: "Button");

    private bool isDodging = false;
    private bool canDodge = true;
    private bool isInvinsible = false;

    private void OnEnable()
    {
        move.Enable();
        dodge.Enable();
    }

    private void OnDisable()
    {
        move.Disable();
        dodge.Disable();
    }

    private void Update()
    {
        // Regular movement
        if (!isDodging)
        {
            Vector2 moveDirection = move.ReadValue<Vector2>();
            Vector3 movementVector = new Vector3(moveDirection.x, moveDirection.y, 0) * speed * Time.deltaTime;
            transform.position += movementVector;
        }

        // Dodge input
        if (dodge.triggered && canDodge)
        {
            Vector2 dodgeDirection = move.ReadValue<Vector2>();
            StartCoroutine(PerformDodge(dodgeDirection));
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Handle boundary interactions based on collision tag
        switch (collision.tag)
        {
            case "LeftBoundary":
                HorizontalWarp(toRight: true);
                break;

            case "RightBoundary":
                HorizontalWarp(toRight: false);
                break;

            case "TopBoundary":
                VerticalBoundaryBlock(top: true);
                break;

            case "BottomBoundary":
                VerticalBoundaryBlock(top: false);
                break;
        }
    }

    private void HorizontalWarp(bool toRight)
    {
        Vector3 newPosition = transform.position;
        if (toRight)
        {
            newPosition.x = -newPosition.x; // Small offset to avoid re-triggering
        }
        else
        {
            newPosition.x = -newPosition.x + offSet; // Small offset to avoid re-triggering
        }
        transform.position = newPosition;
    }

    private void VerticalBoundaryBlock(bool top)
    {
        Vector3 newPosition = transform.position;
        offSet = 1f;

        // Block the player at the top or bottom boundary
        if (top)
        {
            newPosition.y = Camera.main.orthographicSize - offSet; // Block at the top
        }
        else
        {
            newPosition.y = -Camera.main.orthographicSize + offSet; // Block at the bottom
        }

        transform.position = newPosition;
    }

    private IEnumerator PerformDodge(Vector2 direction)
    {
        if (direction == Vector2.zero) direction = Vector2.right; // Default dodge direction if no movement

        canDodge = false; // Prevent new dodges during the current dodge
        isDodging = true; // Stop regular movement during dodge
        isInvinsible = true; // adds invinsibility frames during the dodge

        float dodgeTime = 0f;
        Vector3 dodgeVector = new Vector3(direction.x, direction.y, 0).normalized;

        // Perform the dodge over the specified duration
        while (dodgeTime < dodgeDuration)
        {
            Vector3 dodgePosition = transform.position + dodgeVector * dodgeSpeed * Time.deltaTime;

            // Check vertical boundaries and block if necessary
            if (dodgePosition.y > Camera.main.orthographicSize - offSet)
            {
                dodgePosition.y = Camera.main.orthographicSize - offSet; // Block at the top
            }
            else if (dodgePosition.y < -Camera.main.orthographicSize + offSet)
            {
                dodgePosition.y = -Camera.main.orthographicSize + offSet; // Block at the bottom
            }

            transform.position = dodgePosition;

            dodgeTime += Time.deltaTime;
            yield return null;
        }

        isDodging = false; // Re-enable regular movement after dodge
        isInvinsible = false;

        // Wait for cooldown before allowing another dodge
        yield return new WaitForSeconds(dodgeCooldown);
        canDodge = true;
    }

    public bool get_isInvinsiblie()
    {
        return isInvinsible;
    }
}